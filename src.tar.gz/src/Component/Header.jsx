import React from 'react'
import { NavLink , Link } from 'react-router-dom'

function Header() {
  return (
<div>
  <header className="header-area">
    <div className="container">
      <div className="row d_flex">
        <div className=" col-md-2 col-sm-2">
          <div className="logo">
            <Link to="index.html">Bliss</Link>
          </div>
        </div>
        <div className="col-md-10 col-sm-10">
          <div className="navbar-area">
            <nav className="site-navbar">
              <ul>
                <li> <NavLink to="/">Home </NavLink></li>
                <li> <NavLink to="/about">About </NavLink></li>
                <li> <NavLink to="/services">Service </NavLink></li>
                <li> <NavLink to="/blog">Blog </NavLink></li>
                <li> <NavLink to="/contact">Contact us </NavLink></li>
                <li> <NavLink to="/signup">Sign Up </NavLink></li>
                <li className="d_none"> <NavLink to="Javascript:void(0)"><i className="fa fa-user" aria-hidden="true" /> </NavLink></li>
                <li className="d_none"> <NavLink to="Javascript:void(0)"><i className="fa fa-search" aria-hidden="true" /> </NavLink></li>
              </ul>
              <button className="nav-toggler">
                <span />
              </button>
            </nav>
          </div>
        </div>
      </div>
    </div>
  </header>
</div>

  )
}

export default Header