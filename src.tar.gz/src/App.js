import {BrowserRouter,Routes,Route} from 'react-router-dom'
import Header from './Component/Header';
import Footer from './Component/Footer';


import Index from './Pages/Index';
import About from './Pages/About';
import Blog from './Pages/Blog';
import Contact from './Pages/Contact';
import Services from './Pages/Services';
import Sign_up from './Pages/Sign_up';
import Login from './Pages/Login';

function App() {
  return (
    <div >
      <BrowserRouter>
        <Routes>
          <Route path='/login' element={<> <Login/> </>}></Route>
          <Route path='/' index element={<> <Header/> <Index/>  <Footer/> </>}></Route>
          <Route path='/about' element={<> <Header/>  <About/>  <Footer/> </>}></Route>
          <Route path='/blog' element={<> <Header/> <Blog/> <Footer/> </>}></Route>
          <Route path='/contact' element={<> <Header/> <Contact/> <Footer/> </>}></Route>
          <Route path='/services' element={<> <Header/>  <Services/> <Footer/> </>}></Route>
          <Route path='/signup' element={<> <Header/> <Sign_up/> <Footer/> </>}></Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
