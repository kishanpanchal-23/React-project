import axios from 'axios';
import React, { useEffect, useState } from 'react'

function Manage_contact() {

  const [data,setdata]=useState([]);
  
   useEffect(()=>{
    fetchdata();
   },[])

  const fetchdata = async()=>{
    const res=await axios.get(`http://localhost:3000/contact`)
    setdata(res.data);
  }

  //delete
  const ondelete=async(id)=>{
    const res=await axios.delete(`http://localhost:3000/contact/${id}`);
    fetchdata(res);
  }


  return (
    <div>
       <div className="main-footer"> 
            <div className="card shadow mb-4">
                <div className="container my-auto">
                    <h6 className="m-0 font-weight-bold text-primary"><h2>Contacts</h2></h6>
                </div>
                <div className="card-body">
                    <div className="table-responsive">
                      <table className='table table-bordered' width={"100%"} cellSpacing={0}>
                        <thead>
                          <tr>
                            <td>id</td>
                            <td>Name</td>
                            <td>Email</td>
                            <td>Mobile</td>
                            <td>Password</td>
                            <td>Delete</td>
                          </tr>
                        </thead>
                        <tbody>
                        {
                          data.map((item,index,ent)=>{
                            return(
                              <tr>
                                <td>{item.id}</td>
                                <td>{item.name}</td>
                                <td>{item.email}</td>
                                <td>{item.number}</td>
                                <td>{item.password}</td>
                                <td><button className='btn btn-danger' onClick={()=>{ondelete(item.id)}}>Delete</button></td>
                              </tr>
                            )
                          })
                        }
                        </tbody>
                      </table>
                    </div>
               </div>
            </div>
        </div>
    </div>           
  )
}

export default Manage_contact