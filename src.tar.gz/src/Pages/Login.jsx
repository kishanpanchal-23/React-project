import React from 'react'
import { useState } from 'react'
import axios from 'axios';
import { useNavigate } from "react-router-dom";
// import { Link } from 'react-router-dom';

function Login() {

const result=useNavigate()

  const [formvalue,setformvalue] = useState({
    email:'',
    password:""
  })

  const validation = () => {
     var result = true;

     if(formvalue.email == "" || formvalue.email == null){
        result = false;
        alert('enter your email-id');
        return false; 
      }
     if(formvalue.password == "" || formvalue.password == null){
        result = false;
        alert('Enter correct Password');
        return false;
     }
     return result;
  }

  const onchange = (e) => {
    setformvalue({...formvalue,Id:new Date().getTime().toString(),[e.target.name]:e.target.value});
    console.log(formvalue);
  }

  const onsubmit = async (e) => {
    e.preventDefault();
    if(validation()){
        const res = await axios.get(`http://localhost:3000/user?name=${formvalue.name}`);
        if(res.data.length > 0){
            if(res.data[0].password == formvalue.password){

               //session variable create
               localStorage.setItem('name', res.data[0].name);
               localStorage.setItem('id', res.data[0].id);

               
               alert("Login sucessfully ")
               setformvalue({...formvalue,email:"",password:""});
               result("/dashboard")
              }
               else{   
                 alert("Password Not Valid")
                setformvalue({...formvalue,email:"",password:""});
            }
        }
        else{
            setformvalue({...formvalue,email:"",password:""});

        }

    }
  }



  return (
    <div className='container p-5'>
        <h1>Login Page</h1>
        <br/>
        <form>
           
            <div className="form-group pb-3" >
                <label htmlFor="exampleInputPassword1">Email</label>
                <input type="email" className="form-control" id="exampleInputemail" placeholder="email" value={formvalue.email} onChange={onchange} name='email' />
            </div>

          
            <div className="form-group pb-3" >
                <label htmlFor="exampleInputPassword1">Password</label>
                <input type="password" className="form-control" id="exampleInputPassword1" placeholder="Password" value={formvalue.password} onChange={onchange} name='password' />
            </div>

            <button type="submit" className="btn btn-primary" onClick={onsubmit}>Submit</button>
        </form>
    </div>
  )
}
            

export default Login 


      
        
          