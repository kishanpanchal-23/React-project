import React, { useState } from 'react'
import axios from 'axios';
import { NavLink } from 'react-router-dom';

function Sign_up() {

  const[formvalue,setformvalue]=useState({
    id:"",
    name:"",
    email:"",
    mobile:"",
    password:"",
    status:"",
  })

  const onchange=(e)=>{
   setformvalue({...formvalue,id:new Date().getTime().toString(),status:"Unblock",[e.target.name]:e.target.value})
   console.log(formvalue);
  }

  const validation=()=>{
    let result = true;
    if(formvalue.name == "" || formvalue.name == null){
        alert("Name field is required");
        return false;
    }
    if(formvalue.email == "" || formvalue.email == null){
        alert("Email field is required");
        return false;
    }
    if(formvalue.mobile == "" || formvalue.mobile == null){
        alert("Mobile field is required");
        return false;
    }
    if(formvalue.password == "" || formvalue.password == null){
        alert("Password field is required");
        return false;
    }
     return result;
  }
   
  const onsubmit=async(e)=>{
    e.preventDefault();
    if(validation()){
        const res= await axios.post(`http://localhost:3000/user`,formvalue);
        console.log(res);
        setformvalue({...formvalue,name:"",email:"",mobile:"",password:""})
        // if(res.status === 200){
        //     console.log('res')
        // }
    }
  }

  return (
    <div className="appointment">
  <div className="container">
    <div className="row">
      <div className="col-md-12 ">
        <div className="titlepage text_align_center">
          <h2>Sign Up</h2>
        </div>
      </div>
      <div className="col-md-12">
        <form id="request" className="main_form">
          <div className="row">
            <div className="col-md-6 offset-md-3 ">
              <input className="form_control" value={formvalue.name} onChange={onchange}  placeholder="Your name" type="text" name="name" /> 
            </div>
            <div className="col-md-6 offset-md-3">
              <input className="form_control" value={formvalue.email} onChange={onchange} placeholder="Email" type="email" name="email" /> 
            </div>
            <div className="col-md-6 offset-md-3">
              <input className="form_control" value={formvalue.mobile} onChange={onchange} placeholder="Phone Number" type="number" name="mobile" />                          
            </div>
            <div className="col-md-6 offset-md-3">
              <input className="form_control" value={formvalue.password} onChange={onchange} placeholder="Password" type="password" name="password" />                          
            </div>
            <div className="col-md-12">
              <button className="send_btn" onClick={onsubmit}>Submit</button>
            </div>
          </div>
        </form>
      </div>
          <p>If you already registred <NavLink to="/Login">login</NavLink></p> 
    </div>
  </div>
</div>

  )
}

export default Sign_up