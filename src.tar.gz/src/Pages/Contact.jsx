import axios from "axios";
import React, { useState } from "react";

function Contact() {

  const [formvalue,setformvalue]=useState({
    id:"",
    name:"",
    email:"",
    number:"",
    password:""
  })

  const onchange=(e)=>{
    setformvalue({...formvalue,id:new Date().getTime().toString(),[e.target.name]:e.target.value});
    console.log(formvalue);
  }

  const validation=()=>{
    let result = true;
    if(formvalue.name == "" || formvalue.name == null){
        alert("Name field is required");
        return false;
    }
    if(formvalue.email == "" || formvalue.email == null){
        alert("Email field is required");
        return false;
    }
    if(formvalue.number == "" || formvalue.number == null){
        alert("Mobile field is required");
        return false;
    }
    if(formvalue.password == "" || formvalue.password == null){
        alert("Password field is required");
        return false;
    }
     return result;
  }
  
  const onsubmit=async(e)=>{
    e.preventDefault();
    if(validation()){
      const res=await axios.post(`http://localhost:3000/contact`,formvalue);
      console.log(res);
      setformvalue({...formvalue,name:"",email:"",number:"",password:""})
    }
  }

  return (
    <>
<div className="appointment">
  <div className="container">
    <div className="row">
      <div className="col-md-12 ">
        <div className="titlepage text_align_center">
          <h2>Contact Us</h2>
         </div>
      </div>
      <div className="col-md-12">
        <form id="request" className="main_form">
          <div className="row">
            <div className="col-md-6 offset-md-3 ">
              <input className="form_control" placeholder="Your name" value={formvalue.name} onChange={onchange} type="text" name="name" /> 
            </div>
            <div className="col-md-6 offset-md-3">
              <input className="form_control" placeholder="Email" value={formvalue.email} onChange={onchange} type="email" name="email" /> 
            </div>
            <div className="col-md-6 offset-md-3">
              <input className="form_control" placeholder="Phone Number" value={formvalue.number} onChange={onchange} type="Number" name="number" />                          
            </div>
            <div className="col-md-6 offset-md-3">
              <input className="form_control" placeholder="password" value={formvalue.password} onChange={onchange} type="password" name="password" />                          
            </div>            
            <div className="col-md-12">
              <button className="send_btn" onClick={onsubmit}>Submit</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

    </>

  )
}

export default Contact;
